//! paint 函数：LayoutResult + ComputedStyle + DOM → RenderCommand[]。
//!
//! 遍历 DOM 树，对每个有布局结果的元素节点，查询其 `background-color`
//! 并生成对应的 [`RenderCommand::Rect`]。
//!
//! # 坐标系
//!
//! 坐标由 layout 层给出画布坐标系**绝对坐标**（[`NodeLayout::abs_x`] /
//! [`NodeLayout::abs_y`]，沿 taffy 树自根累加，P2-19）。paint 不再沿 DOM
//! 祖先累加偏移——`display: contents` splice 后 DOM 祖先链 ≠ taffy 父链，
//! DOM 累加会在未来 `position: absolute` / transform 下双重计数。

use crate::color::Color;
use crate::command::{BackgroundImage, RenderCommand, TextAlign};
use crate::image::ImageBits;
use crate::render_tree::{
    apply_text_transform, extract_background_color, extract_background_image_url,
    extract_background_position, extract_background_repeat, extract_background_size,
    extract_border, extract_border_radius, extract_outline, extract_text_color,
    resolve_font_family, resolve_font_size, resolve_font_weight, resolve_line_height,
    resolve_opacity, resolve_text_align,
};
use muskitty_cascade::ComputedStyle;
use muskitty_dom::{Node, NodeKind};
use muskitty_layout::{LayoutResult, NodeLayout};
use std::cell::RefCell;
use std::collections::HashMap;
use std::rc::Rc;

/// 绘制输入：DOM 根 + 每元素 computed style + 布局结果。
pub struct PaintInput<'a> {
    /// DOM 树根节点。
    pub dom: &'a Rc<RefCell<Node>>,
    /// DOM 节点指针地址 → ComputedStyle。
    pub styles: &'a HashMap<usize, ComputedStyle>,
    /// 布局计算结果。
    pub layout: &'a LayoutResult,
    /// 视口矩形 `(x, y, width, height)`。`None` = 不剔除。
    ///
    /// 完全位于视口外的元素矩形不生成绘制指令（P3-6）；与视口相交或
    /// 完全在内的保留。剔除只影响本节点指令，不影响子节点递归（后代
    /// 可能落在视口内）。
    pub viewport: Option<(f32, f32, f32, f32)>,
    /// 背景图资源表：**绝对 URL** → 已解码像素（BG-1）。
    ///
    /// key 用绝对 URL 是因为相对 URL 的解析基准属于文档/样式表加载层
    /// （chrome 侧在加载期把 `url()` 重写为绝对形式并抓取解码），renderer
    /// 只管按键取值——不必依赖 URL 解析实现，也不知道 base URL。
    /// 缺失的 key（抓取/解码失败）→ 该元素不画背景图，页面照常渲染。
    pub images: &'a HashMap<String, ImageBits>,
}

/// 空图像表（无背景图场景 / 测试与示例的便捷值）。
///
/// `PaintInput.images` 是引用，无法用 `&HashMap::new()` 那样的临时值；
/// 这里给进程级的空表，`images: no_images()` 即可。
pub fn no_images() -> &'static HashMap<String, ImageBits> {
    static EMPTY: std::sync::OnceLock<HashMap<String, ImageBits>> = std::sync::OnceLock::new();
    EMPTY.get_or_init(HashMap::new)
}

/// 执行绘制，生成绘制指令列表。
///
/// 遍历 DOM 树，对每个有布局结果且 `background-color` 非透明的元素
/// 生成一个 [`RenderCommand::Rect`]，坐标为画布绝对坐标。
///
/// 指令顺序为 DOM 先序遍历序（父先于子），后端按序绘制即可。
/// z-index / 层叠上下文排序推迟。
pub fn paint(input: &PaintInput) -> Vec<RenderCommand> {
    let mut commands = Vec::new();
    // PERF-11：跨递归层复用的子节点缓冲，避免每层 child_nodes().to_vec()
    // 新建临时 Vec。
    let mut children = Vec::new();
    paint_recursive(
        input.dom,
        input.styles,
        input.layout,
        input.images,
        input.viewport,
        &mut commands,
        &mut children,
        16.0,                                             // 默认 font-size（medium = 16px）
        "serif",                                          // 默认 font-family
        400,                                              // 默认 font-weight（normal）
        16.0 * 1.2, // 默认 line-height（normal = 1.2 × font-size）
        None,       // 默认 text-transform（none）
        muskitty_cascade::WhiteSpace::from_keyword(None), // 默认 white-space（normal）
        TextAlign::Left,
        Color::BLACK,
        false, // 根元素无继承祖先：visibility 初始 visible（非 hidden）
    );
    commands
}

/// 递归遍历 DOM，累积绘制指令。
///
/// 保留 DOM 先序仅为了指令顺序与 style 查询；坐标一律读
/// [`NodeLayout::abs_x`] / [`NodeLayout::abs_y`]，不再传祖先偏移。
#[allow(clippy::too_many_arguments)]
fn paint_recursive(
    node: &Rc<RefCell<Node>>,
    styles: &HashMap<usize, ComputedStyle>,
    layout: &LayoutResult,
    images: &HashMap<String, ImageBits>,
    viewport: Option<(f32, f32, f32, f32)>,
    commands: &mut Vec<RenderCommand>,
    children_scratch: &mut Vec<Rc<RefCell<Node>>>,
    inherited_font_size: f32,
    inherited_font_family: &str,
    inherited_font_weight: u16,
    inherited_line_height: f32,
    inherited_text_transform: Option<&str>,
    inherited_white_space: muskitty_cascade::WhiteSpace,
    inherited_text_align: TextAlign,
    inherited_color: Color,
    // 继承的 `visibility` 是否 hidden（M-3 batch 4）。`visibility` 是继承
    // 属性；hidden 本身盒不绘制但仍占布局，其后代若显式 `visible` 可再
    // 叠出来。
    inherited_visibility_hidden: bool,
) {
    let addr = Rc::as_ptr(node) as usize;

    // 本节点的继承上下文：Element 从自身 style 解析字体样式/行高/转换/
    // white-space/color，其余节点（Text/Comment/...）沿用继承值。
    // text-transform 与 line-height（M-3 batch 3）、white-space（batch 3c）
    // 的语义均由 cascade 单一来源给出，与 layout 测量一致。
    let (
        font_size,
        font_family,
        font_weight,
        line_height,
        text_transform,
        white_space,
        text_align,
        color,
    ) = {
        let node_ref = node.borrow();
        match &node_ref.kind {
            NodeKind::Element(_) => {
                let style = styles.get(&addr);
                let fs = style
                    .and_then(resolve_font_size)
                    .unwrap_or(inherited_font_size);
                let ff = style
                    .and_then(resolve_font_family)
                    .unwrap_or_else(|| inherited_font_family.to_string());
                let fw = style
                    .and_then(resolve_font_weight)
                    .unwrap_or(inherited_font_weight);
                let lh = style
                    .map(|cs| resolve_line_height(cs, fs))
                    .unwrap_or(inherited_line_height);
                let tt = style
                    .and_then(muskitty_cascade::text_transform_keyword)
                    .map(str::to_string)
                    .or_else(|| inherited_text_transform.map(str::to_string));
                let ws = style
                    .map(|cs| {
                        muskitty_cascade::WhiteSpace::from_keyword(
                            muskitty_cascade::white_space_keyword(cs),
                        )
                    })
                    .unwrap_or(inherited_white_space);
                let ta = style
                    .map(resolve_text_align)
                    .unwrap_or(inherited_text_align);
                let c = style.map(extract_text_color).unwrap_or(inherited_color);
                (fs, ff, fw, lh, tt, ws, ta, c)
            }
            _ => (
                inherited_font_size,
                inherited_font_family.to_string(),
                inherited_font_weight,
                inherited_line_height,
                inherited_text_transform.map(str::to_string),
                inherited_white_space,
                inherited_text_align,
                inherited_color,
            ),
        }
    };

    // 本元素是否 overflow 裁剪（非 visible → 子内容裁剪到本元素 box，L-2）。
    let clips = {
        let node_ref = node.borrow();
        match &node_ref.kind {
            NodeKind::Element(_) => styles
                .get(&addr)
                .and_then(|cs| cs.get("overflow"))
                .and_then(|cv| cv.keyword())
                .map(|k| !k.eq_ignore_ascii_case("visible"))
                .unwrap_or(false),
            _ => false,
        }
    };

    // visibility（M-3 batch 4）：继承属性。Element 从自身 style 解析
    // （cascade 已把 inherited 值填充进每个元素的 computed style，故通常
    // 直接反映继承结果；无属性键时耐心沿用继承值）；Text 节点沿用继承值。
    // hidden 元素跳过**自身**盒的绘制（背景/边框/图），但仍递归子节点——
    // 子节点各自判断自己的 visibility，若显式 visible 照常绘制（叠在隐藏
    // 底上）。布局占位不受影响（layout 层不读 visibility）。
    let visibility_hidden = {
        let node_ref = node.borrow();
        match &node_ref.kind {
            NodeKind::Element(_) => match styles.get(&addr).and_then(|cs| cs.get("visibility")) {
                Some(cv) => cv
                    .keyword()
                    .map(|k| k.eq_ignore_ascii_case("hidden"))
                    .unwrap_or(inherited_visibility_hidden),
                None => inherited_visibility_hidden,
            },
            _ => inherited_visibility_hidden,
        }
    };

    // opacity（M-3 batch 4，CSS Color L3 §5.1）合成组。仅对有布局盒的
    // element 施加（与 Rect 生成同条件）——display:contents/无盒元素不产生
    // 组，后代各自决定（已记录为近似）。opacity<1 时本元素**及其整棵子树**
    // 作为一个整体离屏合成后再按 alpha 混合到背景；opacity=0 整棵子树不可见
    // （跳过全部指令）。值域 [0,1]，缺失/非法 → 1（无组，与现状逐字节一致）。
    let opacity_value = {
        let node_ref = node.borrow();
        match &node_ref.kind {
            NodeKind::Element(_) if layout.get(addr).is_some() => {
                styles.get(&addr).map(resolve_opacity).unwrap_or(1.0)
            }
            _ => 1.0,
        }
    };
    // opacity 组命令只在 (0,1) 发出；否则不出（1 无操作 / 0 走下方早退）。
    let opacity_group = opacity_value > 0.0 && opacity_value < 1.0;

    // opacity: 0 → 整棵子树不可见，跳过本元素与全部后代（不含任何指令，
    // 含 Clip/outline/递归）。
    if opacity_value == 0.0 {
        return;
    }

    // opacity 组开始：在本元素**任何指令之前**压入 Opacity，使其包裹
    // 本元素的 Rect、overflow Clip 对、全部子节点与 outline——整棵子树最
    // 终作为一个整体离屏合成。EndOpacity 在子树全部结束后（EndClip 与
    // outline 之后）发出，见函数末尾。
    if opacity_group {
        commands.push(RenderCommand::Opacity {
            opacity: opacity_value,
        });
    }

    // 按节点类型生成绘制指令。
    {
        let node_ref = node.borrow();
        match &node_ref.kind {
            // Text 节点 → Text 命令（T-2）。text 无自身 style，用继承上下文。
            // M-3 batch 3c：内容先过 white-space 折叠（cascade `apply_white_space`
            // 单一来源，与 layout 测量同一实现）；折叠后为空的纯空白节点无
            // 墨迹可画，跳过。`pre` 系保留空白 → 空白本身可能仍是墨迹间内容，
            // 不再一刀切 trim 判断，以折叠输出为准。
            NodeKind::Text(text) => {
                // 先 transform 后折叠（§4 Order；与 layout convert 同序）。
                let transformed = apply_text_transform(&text.data, text_transform.as_deref());
                let content = muskitty_cascade::apply_white_space(&transformed, white_space);
                if !content
                    .trim_matches(|c: char| c != '\n' && c.is_ascii_whitespace())
                    .is_empty()
                {
                    // M-3 batch 4：Text 沿用当前继承的 visibility——祖先 hidden
                    // 且无显式 visible 覆盖 → 跳过文本绘制（自身不可见）。
                    if !visibility_hidden {
                        if let Some(node_layout) =
                            layout.get(addr).filter(|l| in_viewport(l, viewport))
                        {
                            commands.push(RenderCommand::Text {
                                x: node_layout.abs_x,
                                y: node_layout.abs_y,
                                width: node_layout.width,
                                text: content.into_owned(),
                                font_size,
                                line_height,
                                font_family: font_family.clone(),
                                font_weight,
                                text_align,
                                color,
                                wrap: white_space.wrap,
                            });
                        }
                    }
                }
            }
            // Element 节点 → Rect 命令（背景色 + 背景图 + 四边边框）。
            NodeKind::Element(_) => {
                // M-3 batch 4：`visibility: hidden` 的盒不绘制自身（背景/边框/图），
                // 但仍占布局，且后代若显式 visible 会在其后叠出。
                if visibility_hidden {
                    // 见开头的块注释：跳过自身盒指令，但子节点递归不受影响。
                } else if let Some(node_layout) = layout.get(addr) {
                    if in_viewport(node_layout, viewport) {
                        if let Some(style) = styles.get(&addr) {
                            let bg =
                                extract_background_color(style).filter(|c| !c.is_transparent());
                            // `currentcolor` 取本元素文字色（M-3 batch 2）
                            let border = extract_border(style, color);
                            // BG-1 收尾：背景图按绝对 URL 查已解码资源表，并
                            // 合并 background-repeat/position/size 绘制参数。
                            // 抓取或解码失败的 key 缺失 → 不画图（页面照常
                            // 渲染）。
                            let image = extract_background_image_url(style)
                                .and_then(|url| images.get(&url))
                                .cloned()
                                .map(|bits| BackgroundImage {
                                    bits,
                                    repeat: extract_background_repeat(style),
                                    position: extract_background_position(style),
                                    size: extract_background_size(style),
                                });

                            // M-3 batch 5：四角圆角（% 按盒宽/高折算）。
                            let border_radius =
                                extract_border_radius(style, node_layout.width, node_layout.height);

                            // 有背景色/背景图/边框时生成绘制指令（绝对坐标）。
                            if bg.is_some() || border.is_some() || image.is_some() {
                                commands.push(RenderCommand::Rect {
                                    x: node_layout.abs_x,
                                    y: node_layout.abs_y,
                                    width: node_layout.width,
                                    height: node_layout.height,
                                    background: bg,
                                    border,
                                    image,
                                    border_radius,
                                });
                            }
                        }
                    }
                }
            }
            _ => {}
        }
    }

    // overflow 裁剪：本元素背景/边框已绘制，其子内容裁剪到本元素 box（L-2）。
    if clips {
        if let Some(node_layout) = layout.get(addr) {
            commands.push(RenderCommand::Clip {
                x: node_layout.abs_x,
                y: node_layout.abs_y,
                width: node_layout.width,
                height: node_layout.height,
            });
        }
    }

    // 递归子节点（无论本节点是否绘制；display:contents 等无盒元素的后代
    // 仍需在 DOM 先序中遍历到）。PERF-11：子节点收集进复用缓冲，`take`
    // 为本次局部分片（递归期间缓冲保持空给子层复用）；递归结束后归还，
    // 让最深层的分配 capacity 被最外层持续复用。
    children_scratch.clear();
    children_scratch.extend(node.borrow().child_nodes().iter().cloned());
    let children = std::mem::take(children_scratch);
    for child in &children {
        paint_recursive(
            child,
            styles,
            layout,
            images,
            viewport,
            commands,
            children_scratch,
            font_size,
            &font_family,
            font_weight,
            line_height,
            text_transform.as_deref(),
            white_space,
            text_align,
            color,
            // 子节点继承本元素的 visibility（hidden 继续往下传，直至某元素
            // 显式 visible 覆盖）。
            visibility_hidden,
        );
    }
    *children_scratch = children;

    if clips {
        commands.push(RenderCommand::EndClip);
    }

    // 轮廓（M-3 batch 2）：绘制在 border box 之外、元素及其后代之上，故在
    // 子节点递归与本元素裁剪恢复之后发出（CSS UI L4 §4；outline 不影响布局）。
    // CSS Visibility L3 §1：`visibility: hidden` 使元素**自身**（含其 outline）
    // 不可见，故与 Rect 同受 `visibility_hidden` 守卫——后代显式 `visible`
    // 仍会自行发出自己的 outline，不受此处影响。
    if !visibility_hidden {
        if let NodeKind::Element(_) = node.borrow().kind {
            if let Some(style) = styles.get(&addr) {
                if let Some(outline) = extract_outline(style, color) {
                    if let Some(node_layout) = layout.get(addr).filter(|l| in_viewport(l, viewport))
                    {
                        commands.push(RenderCommand::Outline {
                            x: node_layout.abs_x,
                            y: node_layout.abs_y,
                            width: node_layout.width,
                            height: node_layout.height,
                            outline_width: outline.width,
                            color: outline.color,
                            style: outline.style,
                        });
                    }
                }
            }
        }
    }

    // opacity 组结束：在本元素子树全部结束后（EndClip 与 outline 之后）压入
    // EndOpacity，把 Rect + 子节点 + outline + overflow clip 对整体作为一个
    // 离屏合成单元交还后端。此处与函数开头压入的 Opacity 严格配对。
    if opacity_group {
        commands.push(RenderCommand::EndOpacity);
    }
}

/// P3-6: viewport culling —— 完全位于视口外的盒跳过绘制。
fn in_viewport(node_layout: &NodeLayout, viewport: Option<(f32, f32, f32, f32)>) -> bool {
    match viewport {
        Some((vx, vy, vw, vh)) => {
            !(node_layout.abs_x + node_layout.width <= vx
                || node_layout.abs_y + node_layout.height <= vy
                || node_layout.abs_x >= vx + vw
                || node_layout.abs_y >= vy + vh)
        }
        None => true,
    }
}

// 单元测试见 tests/paint.rs（使用 muskitty-html5-parser 构造真实 DOM）。
