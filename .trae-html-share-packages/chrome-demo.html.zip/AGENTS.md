# AGENTS.md

This file provides guidance to AI coding agents (Codex CLI / Claude Code / etc.) when working with code in this repository.

## Project: MusKitty

从零用 Rust 重写浏览器核心模块。独立实现，不 fork Chromium。Chromium 源码仅作参考，WHATWG 规范和 WPT 测试套件是行为 ground truth。

当前阶段：Phase 4（Renderer）B-3 / B-4 已完成，DOM→CSS→Layout→Render 全链路打通，最小可运行 demo 工作（HTML+CSS → PNG）。HTML 解析层（tokenizer + tree construction + DOM）、CSS Syntax tokenizer/parser/grammar hooks + Selectors Level 4 解析与匹配（WPT parsing 99.8%）+ CSS Values + CSSOM + Cascade + Layout + tiny-skia Renderer 均已完成。Phase 5（Network）已启动基础搭建（`NetworkFetcher` trait 抽象 + reqwest 后端，远期自研 HTTP 栈，见 [docs/plans/2026-08-09-phase5-network.md](docs/plans/2026-08-09-phase5-network.md)）；2026-09-06 已接驳 chrome 地址栏导航（顶级文档 GET：http/https 抓取 + file 加载，chrome `navigation` 模块 + `fetch_blocking` 同步入口），2026-09-14 补齐**样式表来源（CS-1）**：DOM 文档序采集 `<style>`/`<link rel=stylesheet>`、相对 URL 解析（`muskitty-network::url`，WHATWG URL 参考实现）、外链抓取（scheme 策略/上限/去重，导航线程内）、`@import` 加载期展开、最小 UA 样式表（HTML §15），见 [docs/plans/2026-09-13-external-css-and-css-sources.md](docs/plans/2026-09-13-external-css-and-css-sources.md)；其余子资源（img/script）与历史栈待后续。全项目审计（[docs/audit-2026-08-08-full-scan.md](docs/audit-2026-08-08-full-scan.md)）B1-B14 已全部完成、P0/P1/P2 清零。2026-09-06 漏洞/架构/性能全量审计（[docs/audit-2026-09-06-vuln-arch-perf.md](docs/audit-2026-09-06-vuln-arch-perf.md)）的 4 项 P0（V-1 var() 输出预算 / CSS-P1 规则级嵌套守卫 / SEL-1 匹配记忆化+预算 / SEL-2 :has 嵌套禁止）已修复落地于 muskitty-dev 的 cascade/css-parser/selectors（修复记录见该审计第十节），并顺带完成 P1 的 SEL-3 与 CAS-1/2/3；其余 P1/P2/P3 按审计批次建议排后续轮。已完成：文本渲染（cosmic-text 集成）→ 布局增强（position/overflow/grid）→ 窗口化（winit + softbuffer 真窗口）→ 外部依赖解耦（layout/renderer/network，见 [docs/decisions/2026-08-16-external-dependency-decoupling.md](docs/decisions/2026-08-16-external-dependency-decoupling.md)）→ T-3 换行与字体属性（2026-08-22）→ W-2~W-5（DPI/输入/headless/多标签，2026-08-29）→ M-3 batch 1/2/3（border 简写、方向性边框 + outline、line-height + text-transform）→ W-3（WPT 选择器对齐，2026-09-13）→ CS-1 样式表来源（2026-09-14）→ **M-3 batch 3c（white-space + 空白折叠，测量与绘制共用 cascade 单一实现）** + **BG-1（background-image 图像解码绘制管线：cascade 注册 + renderer `ImageBits`/PNG 解码/平铺 + chrome 子资源抓取）** + **MQ-V（@media 求值按 MQ L4 §3 重写为 Kleene 三值）**（2026-09-18）；M-3 batch 3b（letter-spacing/word-spacing/font-style）与批次 5 余项（border-radius / 渐变 / box-shadow / background-repeat-position-size）待后续（总账见 [docs/plans/2026-09-12-css-completion.md](docs/plans/2026-09-12-css-completion.md)）；Network 已接驳 chrome 导航与样式表子资源（保持 trait 抽象 + reqwest 基础，自研栈路线不变）。

本主仓库 (`Ink-dark/MusKitty`) 作 workspace 协调中心：`members = ["crates/muskitty-renderer", "crates/muskitty-network", "crates/muskitty-chrome"]`，11 个已剥离 crate 列在 `exclude` 中并各自独立 git 仓库于 `muskitty-dev/` org 下，新设备 clone 主仓库后通过 `fetch-crates.ps1` / `fetch-crates.sh` 一次性拉取（**crate 清单单一来源：根目录 `crates.json`**，新增/剥离 crate 只改它，脚本与 CI 均读取该文件并三方对账）。

## Build & Test Commands

主仓库 `members = ["crates/muskitty-renderer", "crates/muskitty-network", "crates/muskitty-chrome"]`，可直接 `cargo check --workspace` 一次性检查所有 in-tree crate。其他 11 个独立 crate 在各自目录里构建。

```bash
# 在工作区根（主仓库）一次性检查/测试所有 in-tree crate
cargo check --workspace
cargo test --workspace
cargo clippy --workspace --all-targets -- -D warnings
cargo fmt --all -- --check

# 在某个独立 crate 目录下（例如 crates/muskitty-css-parser/）
cargo check                             # 检查该 crate（必须零 warning）
cargo test                              # 运行该 crate 全部测试
cargo test --lib                        # 只跑 lib tests
cargo test --tests                     # 只跑 integration tests
cargo fmt --all -- --check              # 格式检查
cargo clippy --all-targets -- -D warnings

# 跨 crate 联合构建（开发时本地 workspace 仍可解析 path 依赖）
cd D:\Muskitty\crates\muskitty-selectors && cargo test

# 新设备初始化（拉取独立 crate；清单见 crates.json，脚本结尾会做三方对账）
pwsh ./fetch-crates.ps1          # Windows
bash ./fetch-crates.sh           # Linux/macOS
```

依赖 path：每个 crate 的 `Cargo.toml` 用 `path = "../muskitty-xxx"` 引用同级 crate。本地开发时 `crates/` 目录下所有 crate 共存即可解析。CI 上每个仓库的 `scripts/setup-deps.sh` 负责克隆依赖到 `../` 相对路径。

## Architecture

```
MusKitty/                               # 主仓库 (Ink-dark/MusKitty)，workspace 协调中心
├── Cargo.toml                          # members = [renderer, network, chrome], exclude = [11 个已剥离 crate]
├── PROGRESS.md                         # 项目进度面板
├── CLAUDE.md / AGENTS.md               # 硬约束指南（本文件）
├── goal.md                             # 当轮任务清单与退出条件
├── README.md                           # 项目 README
├── fetch-crates.ps1 / .sh              # 一次性拉取独立 crate 的脚本（清单读 crates.json）
├── crates.json                         # crate 清单单一来源：standalone（已剥离）+ bundled（workspace member）
├── crates/                             # workspace member + 独立 git 仓库
│   ├── muskitty-renderer/              # 📦 workspace member (tiny-skia backend, 未剥离)
│   ├── muskitty-network/               # 📦 workspace member (NetworkFetcher trait + reqwest 后端 + fetch_blocking, 已接驳 chrome 导航)
│   ├── muskitty-chrome/                # 📦 workspace member (自绘 chrome + winit 窗口 + 地址栏导航)
│   ├── muskitty-cascade/               # 🔗 已剥离 (CSS Cascade L5)
│   ├── muskitty-cssom/                 # 🔗 已剥离 (CSSOM)
│   ├── muskitty-layout/                # 🔗 已剥离 (taffy 0.12 layout)
│   ├── muskitty-dom/                   # 🔗 已剥离 (DOM Core)
│   ├── muskitty-html5-tokenizer/        # 🔗 已剥离 (WHATWG §13.2.5 tokenizer)
│   ├── muskitty-html5-parser/           # 🔗 已剥离 (WHATWG §13.2.6 tree construction)
│   ├── muskitty-css-tokenizer/         # 🔗 已剥离 (CSS Syntax §4.3 tokenizer)
│   ├── muskitty-css-parser/            # 🔗 已剥离 (CSS Syntax §5 parser)
│   ├── muskitty-css/                   # 🔗 已剥离 (Facade: tokenizer + parser)
│   ├── muskitty-selectors/             # 🔗 已剥离 (Selectors Level 4)
│   ├── muskitty-css-values/            # 🔗 已剥离 (CSS Values L4)
└── docs/
    ├── spec/                           # 规范源文件（CSS Syntax Overview.bs 等）
    ├── plans/                          # 当前阶段计划文档
    ├── audit-2026-08-08-full-scan.md   # 全项目代码审查报告
    ├── decisions/                      # 架构决策记录（ADR）
    └── archive/                        # 历史设计文档 / 审查报告
```

依赖拓扑（crates.io 发布顺序）：

```
muskitty-dom ────────────────────────────────────────────┐
                                                         ├─→ muskitty-selectors ──┐
muskitty-css-tokenizer ─→ muskitty-css-parser ─→ muskitty-css ──────────────────────┤
                                                         ├─→ muskitty-css-values  ├─→ muskitty-cascade (已剥离) ─→ muskitty-layout (已剥离)
muskitty-html5-tokenizer ─→ muskitty-html5-parser        │                         │
                                                         └─→ muskitty-cssom ──────┘                         └─→ muskitty-renderer (in-tree)
```

## Hard Rules

### Technical
- Rust stable，零 unsafe（FFI 边界需架构师批准）
- 零 C/C++ 依赖。标准库能搞定不引 crate
- 每个模块独立 crate，测试覆盖率 ≥ 80%
- 公共 API 必须有 doc comment，引用规范条款
- 参考优先级：**WHATWG > WPT > Chromium 源码**
- 外部依赖解耦：本体 crate 公共 API 只暴露自身抽象类型，外部依赖（taffy/tiny-skia/cosmic-text/reqwest 等）类型不得出现在 pub 导出（见 [docs/decisions/2026-08-16-external-dependency-decoupling.md](docs/decisions/2026-08-16-external-dependency-decoupling.md)）

### Behavior
1. **Read before write** — 动手前读规范对应章节 + Chromium 参考实现。不确定就问，不猜
2. **Think before code** — 先说清楚选择和取舍。真不懂就停
3. **Simplicity** — 最少代码解决问题。抵抗过早抽象。硬编码直到有真实理由需要配置
4. **Surgical changes** — diff 必须和任务一样小。不顺手改别的文件
5. **Verification** — 每个子任务先定义 success criterion。修 bug：先写 failing test → 看它 fail → 修 → 看它 pass
6. **Goal-driven** — ❌ "写个 tokenizer" ✅ "按 WHATWG §12.1 实现 Tokenizer trait，正确处理 data/rcdata/script-data 状态切换，附单元测试"
7. **Debugging** — 炸了先查，别猜。读完整报错。复现后再改，一次只改一处
8. **Self-check** — 提防：Kitchen Sink / Wrong Abstraction / Optimistic Path / Runaway Refactor

### Commit Discipline
- 每个子任务 + cargo check/test + cargo fmt 通过后立即 commit
- Message 格式：`[module] what + why`，例：`[tokenizer] add Data state, matches WHATWG §13.2.5.1`
- 必须 `git add <specific files>`，禁止 `git commit -a`
- 禁止 `git rebase -i` 压缩已完成的 commit
- WPT 语义比对通过后才允许 commit（架构师执行比对）

### Versioning Discipline
- 改逻辑（修 bug / 加特性 / 换行为）必须在提交里把该 crate 的 `Cargo.toml` `version` 随手 +1（patch），不允许"改了代码却发版版本号不变"
- 判据：crate 的 git tag（`vX.Y.Z`，`git describe --tags`）落后于 HEAD 提交（`N>0`，即 tag 之后还有提交未发版）时，patch 版本必须 ≥ 已打 tag 的版本，否则视为失配
- `path =` 依赖在同一工作区内由 path 覆盖版本号，仅作安全校验，故 patch 升级不会破坏依赖方 `^X.Y.Z` 要求——无需连带改其他 crate 的依赖段（除非涉及 semver-incompatible 的大版本/次版本变更）
- 发版动作（打 tag / push / 发布 crates.io）另行人工执行，bump 版本号只改 `Cargo.toml`

### Extraction Discipline (项目特有，当前暂停)
- 每个 crate 达到下一层入场门槛的 spec 覆盖后，剥离为独立 git 仓库（Hard extraction：crate 有自己的 `[workspace]` 块，从父 workspace `members` 移到 `exclude`）
- 主仓库 `.gitignore` 加入 `crates/<crate-name>/` 排除项
- 新仓库加 `LICENSE` (Apache-2.0) + `README.md` + `.github/workflows/ci.yml` + `.github/workflows/publish.yml` + `scripts/setup-deps.sh`
- `CARGO_REGISTRY_TOKEN` GitHub secret 通过 `gh secret set CARGO_REGISTRY_TOKEN --repo muskitty-dev/<crate>` 配置
- 发布顺序遵循依赖拓扑（先底层后上层）
- **当前状态**：剥离任务暂停。未剥离 crate（cascade / cssom / renderer）作为主仓库 workspace member 直接版本控制。新设备通过 `fetch-crates.ps1` / `fetch-crates.sh` 一次性拉取 11 个已剥离 crate。

### Verification Flow
1. 你写完 → `cargo check` 零 warning
2. `cargo test` 全绿
3. 架构师跑语义比对（WPT 输出 vs 你的实现）
4. 比对通过 → `git add <files>` + commit
5. 比对不通过 → 根据差异修，回到步骤 1
6. 你不许自行宣布"完成"

### Goal-Driven Execution (本轮任务)
- 每轮任务有显式 [goal.md](goal.md)，列明任务清单与每个任务的退出条件
- 任务完成的判据是退出条件全部满足，不是 agent 自行宣布
- 退出条件未满足时继续迭代，不要提前停下
- 退出条件全部满足后立即 commit + push，然后退出本轮，等待用户下一轮指令

## Style Conventions
- 别用 newtype 包裹，除非需要 orphan rule
- 别为未来需求加参数。真有需求时再加
- tokenizer 内部可多次 `clone()`，等 profiling 证明热路径以后再去掉
- 别自己写 interner——需要时用标准库类型
